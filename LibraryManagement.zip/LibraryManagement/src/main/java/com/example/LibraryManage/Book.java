package com.example.LibraryManage;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name="book")
public class Book {

  
    @Id  
  @Column(name="isbn")
  Long isbn;
  
  @Column(name="title")
  String title;
  
  @Column(name="ser_name")
  String serial;
  
  @Column(name="description")
  String description;
  
  @Column(name="author")
  String author;
  
  @Column(name="publication")
  String publication;
  
  @Column(name="story")
  String story;
  
  public Book() { }
  
  public Book(Long isbn, String title, String serial, String description, String author, String publication, String story) {
    this.isbn = isbn;
    this.title = title;
    this.serial = serial;
    this.description = description;
    this.author = author;
    this.publication = publication;
    this.story=story;
  }
  
  
  
  public String getStory() {
	return story;
}

public void setStory(String story) {
	this.story = story;
}

public String getPublication() {
	return publication;
}

public void setPublication(String publication) {
	this.publication = publication;
}

public String getAuthor() {
  return author;
}

public void setAuthor(String author) {
  this.author = author;
}

public Long getIsbn() {
    return isbn;
  }
  public void setIsbn(Long isbn) {
    this.isbn = isbn;
  }
  public String getTitle() {
    return title;
  }
  public void setTitle(String title) {
    this.title = title;
  }
  public String getSerial() {
    return serial;
  }
  public void setSerial(String serial) {
    this.serial = serial;
  }
  public String getDescription() {
    return description;
  }
  public void setDescription(String description) {
    this.description = description;
  }
  
}