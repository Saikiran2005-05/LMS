package com.example.LibraryManage;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ContactDao extends JpaRepository<Contact,String>{
  Contact findByName(String name);
}