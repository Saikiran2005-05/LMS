package com.example.LibraryManage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibraryManageApplicationTests {

	@Test
	void contextLoads() {
	}

}
